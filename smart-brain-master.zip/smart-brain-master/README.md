# SmartBrain - v2
Final project for Udemy course

1. Clone this repo
2. Run `npm install`
3. Run `npm start`
